Copy ATOM2.0.def.json to following dir
	C:\Program Files\Cura 2.3\resources\definitions

Copy ATOM2_0.stl to following dir
	
	C:\Program Files\Cura 2.3\resources\meshes
